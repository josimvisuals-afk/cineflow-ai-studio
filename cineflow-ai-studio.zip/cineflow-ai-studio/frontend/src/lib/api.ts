export const API_URL = (
  process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000"
).replace(/\/$/, "");

export const STATUS_ORDER = [
  "draft",
  "researching",
  "scripting",
  "storyboarding",
  "rendering",
  "completed",
] as const;

export type ProjectStatus = (typeof STATUS_ORDER)[number];

export interface Project {
  id: string;
  title: string;
  topic: string;
  target_duration_seconds: number;
  status: ProjectStatus;
  created_at: string;
  updated_at: string;
}

export interface NewProject {
  title: string;
  topic: string;
  target_duration_seconds: number;
}

export type HealthState = "online" | "degraded" | "offline";

export class ApiError extends Error {
  status: number;

  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

async function parseError(res: Response): Promise<string> {
  try {
    const body = await res.json();
    if (typeof body?.detail === "string") return body.detail;
    if (Array.isArray(body?.detail)) {
      return body.detail
        .map((d: { loc?: unknown[]; msg?: string }) => {
          const field = (d.loc ?? []).slice(1).join(".");
          return field ? `${field}: ${d.msg}` : String(d.msg);
        })
        .join("; ");
    }
  } catch {
    // body was not JSON; fall through to the generic message
  }
  return `Request failed (${res.status})`;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    ...init,
    headers: init?.body ? { "Content-Type": "application/json" } : undefined,
    cache: "no-store",
  });
  if (!res.ok) throw new ApiError(await parseError(res), res.status);
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

/** Backend reachable + DB ok => online; backend up but DB down (503) => degraded. */
export async function getHealth(signal?: AbortSignal): Promise<HealthState> {
  const res = await fetch(`${API_URL}/api/health`, { cache: "no-store", signal });
  if (res.ok) return "online";
  if (res.status === 503) return "degraded";
  return "offline";
}

export function listProjects(): Promise<Project[]> {
  return request<Project[]>("/api/projects");
}

export function createProject(payload: NewProject): Promise<Project> {
  return request<Project>("/api/projects", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function deleteProject(id: string): Promise<void> {
  return request<void>(`/api/projects/${id}`, { method: "DELETE" });
}
