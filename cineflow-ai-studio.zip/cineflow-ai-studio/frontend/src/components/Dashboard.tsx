"use client";

import { useCallback, useEffect, useState } from "react";
import NewProjectModal from "@/components/NewProjectModal";
import ProjectCard from "@/components/ProjectCard";
import { API_URL, deleteProject, listProjects, type Project } from "@/lib/api";

export default function Dashboard() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setProjects(await listProjects());
    } catch {
      setError(
        `Can't load projects from ${API_URL}. Start the backend and check that PostgreSQL is running.`,
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const closeModal = useCallback(() => setModalOpen(false), []);

  async function handleDelete(id: string) {
    await deleteProject(id);
    setProjects((prev) => prev.filter((p) => p.id !== id));
  }

  function handleCreated(project: Project) {
    setProjects((prev) => [project, ...prev]);
    setModalOpen(false);
  }

  return (
    <section aria-labelledby="projects-heading">
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2
            id="projects-heading"
            className="font-serif text-3xl font-semibold tracking-tight"
          >
            Documentary projects
          </h2>
          <p className="mt-1 text-dim">
            {loading
              ? "Loading projects"
              : `${projects.length} ${projects.length === 1 ? "project" : "projects"}`}
          </p>
        </div>
        <button
          type="button"
          onClick={() => setModalOpen(true)}
          className="rounded-md bg-lamp px-5 py-2.5 text-sm font-semibold text-ink hover:brightness-110"
        >
          New Documentary Project
        </button>
      </div>

      {error && (
        <div
          role="alert"
          className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-ember/50 bg-ember/10 px-4 py-3 text-[#f08a4b]"
        >
          <p className="text-sm">{error}</p>
          <button
            type="button"
            onClick={load}
            className="rounded-md border border-ember/60 px-3 py-1.5 text-sm font-medium hover:bg-ember/15"
          >
            Retry
          </button>
        </div>
      )}

      {loading && !error && (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3" aria-hidden="true">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="h-56 rounded-md border border-rule bg-panel motion-safe:animate-pulse"
            />
          ))}
        </div>
      )}

      {!loading && !error && projects.length === 0 && (
        <div className="rounded-md border border-dashed border-rule px-6 py-16 text-center">
          <p className="font-serif text-xl">No documentaries yet</p>
          <p className="mx-auto mt-2 max-w-sm text-dim">
            Create a project with a title, a topic and a target runtime to start
            your first film.
          </p>
          <button
            type="button"
            onClick={() => setModalOpen(true)}
            className="mt-6 rounded-md bg-lamp px-5 py-2.5 text-sm font-semibold text-ink hover:brightness-110"
          >
            New Documentary Project
          </button>
        </div>
      )}

      {!loading && projects.length > 0 && (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((project) => (
            <ProjectCard key={project.id} project={project} onDelete={handleDelete} />
          ))}
        </div>
      )}

      {modalOpen && (
        <NewProjectModal onClose={closeModal} onCreated={handleCreated} />
      )}
    </section>
  );
}
