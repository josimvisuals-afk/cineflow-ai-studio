"use client";

import { useEffect, useState } from "react";
import { getHealth, type HealthState } from "@/lib/api";

type State = HealthState | "checking";

const COPY: Record<State, { label: string; dot: string }> = {
  checking: { label: "Checking backend", dot: "bg-dim motion-safe:animate-pulse" },
  online: { label: "Backend and database connected", dot: "bg-[#8fb573]" },
  degraded: { label: "Backend up, database unreachable", dot: "bg-lamp" },
  offline: { label: "Backend offline", dot: "bg-[#d65a4a]" },
};

const POLL_MS = 15_000;

export default function HealthIndicator() {
  const [state, setState] = useState<State>("checking");

  useEffect(() => {
    let cancelled = false;
    let current: AbortController | null = null;

    async function check() {
      current?.abort();
      const controller = new AbortController();
      current = controller;
      try {
        const next = await getHealth(controller.signal);
        if (!cancelled) setState(next);
      } catch {
        if (!cancelled && !controller.signal.aborted) setState("offline");
      }
    }

    check();
    const id = setInterval(check, POLL_MS);
    return () => {
      cancelled = true;
      clearInterval(id);
      current?.abort();
    };
  }, []);

  const { label, dot } = COPY[state];

  return (
    <div
      role="status"
      aria-live="polite"
      className="flex items-center gap-2 rounded-full border border-rule bg-panel px-3 py-1.5 text-sm text-dim"
    >
      <span className={`h-2.5 w-2.5 rounded-full ${dot}`} aria-hidden="true" />
      <span>{label}</span>
    </div>
  );
}
