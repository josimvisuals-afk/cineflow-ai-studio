import type { ProjectStatus } from "@/lib/api";

const STYLES: Record<ProjectStatus, string> = {
  draft: "border-rule bg-ink text-dim",
  researching: "border-lamp/30 bg-lamp/10 text-lamp",
  scripting: "border-lamp/30 bg-lamp/10 text-lamp",
  storyboarding: "border-lamp/40 bg-lamp/15 text-lamp",
  rendering: "border-ember/50 bg-ember/15 text-[#f08a4b]",
  completed: "border-[#8fb573]/40 bg-[#8fb573]/10 text-[#a8cc8c]",
};

export default function StatusBadge({ status }: { status: ProjectStatus }) {
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium capitalize ${STYLES[status]}`}
    >
      {status}
    </span>
  );
}
