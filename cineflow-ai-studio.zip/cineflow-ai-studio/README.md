# CineFlow AI Studio

Step 1: monorepo scaffold with a real FastAPI + PostgreSQL backend and a Next.js dashboard.

```
backend/    FastAPI, SQLAlchemy, PostgreSQL
frontend/   Next.js 15 (App Router), TypeScript, Tailwind CSS
remotion/   Placeholder for the Step 5 video renderer
```

## Run it

```bash
# 1. Infrastructure (PostgreSQL 16 on 5432, Redis 7 on 6379)
cp .env.example .env
docker compose up -d

# 2. Backend (http://localhost:8000, docs at /docs)
cd backend
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

# 3. Frontend (http://localhost:3000), in a new terminal
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```

Quick API check: `curl http://localhost:8000/api/health`

Tables are created on backend startup (`Base.metadata.create_all`). Alembic is installed and ready to take over in a later step.
