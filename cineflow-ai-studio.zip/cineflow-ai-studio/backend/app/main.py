import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app import models  # noqa: F401  (registers models on Base.metadata)
from app.api.routes import projects
from app.core.config import settings
from app.db.base import Base
from app.db.session import engine

logger = logging.getLogger("cineflow")


@asynccontextmanager
async def lifespan(_: FastAPI):
    # Step 1: create tables directly. Alembic migrations can take over later.
    try:
        Base.metadata.create_all(bind=engine)
    except Exception:  # keep the API up so /api/health can report the DB problem
        logger.exception("Could not create tables. Is PostgreSQL running?")
    yield


app = FastAPI(title="CineFlow AI Studio API", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(projects.router)
